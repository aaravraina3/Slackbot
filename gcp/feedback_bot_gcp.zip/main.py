from cloud_function import main

# This is the entry point for Cloud Functions
def generate_feedback_bot(request):
    return main(request)
